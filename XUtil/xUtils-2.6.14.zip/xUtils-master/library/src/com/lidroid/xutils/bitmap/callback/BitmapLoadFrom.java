package com.lidroid.xutils.bitmap.callback;

/**
 * Author: wyouflf
 * Date: 13-11-1
 * Time: 下午8:17
 */
public enum BitmapLoadFrom {
    MEMORY_CACHE, DISK_CACHE, URI
}
